#!/usr/bin/env bash
# scan-solutions.sh — Quick inventory of all solution.js files
# Usage: bash scan-solutions.sh <question-bank-root>
# Output: TSV to stdout

set -euo pipefail

ROOT="${1:?Usage: scan-solutions.sh <question-bank-root>}"

printf "PRIORITY\tQUESTION\tLINES\tFUNCS\tCLASSES\tSTATUS\n"

find "$ROOT" -name "solution.js" -type f | sort | while read -r f; do
  rel="${f#$ROOT/}"
  priority=$(echo "$rel" | cut -d'/' -f1)
  qdir=$(dirname "$rel")
  qname=$(basename "$qdir")

  lines=$(wc -l < "$f" | tr -d ' ')

  funcs=$(grep -c '\bfunction\b' "$f" || true)
  classes=$(grep -c '^\s*class ' "$f" || true)

  status="OK"
  if (( lines > 120 && funcs > 5 )); then
    status="OVER-ENGINEERED"
  elif (( lines > 120 )); then
    status="LONG"
  elif (( funcs > 5 )); then
    status="COMPLEX"
  fi

  printf "%s\t%s\t%s\t%s\t%s\t%s\n" "$priority" "$qname" "$lines" "$funcs" "$classes" "$status"
done
