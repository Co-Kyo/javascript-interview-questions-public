#!/usr/bin/env bash
# detect-patterns.sh — Detect common over-engineering patterns in solution.js files
# Usage: bash detect-patterns.sh <question-bank-root>
# Output: Per-file pattern detections

set -euo pipefail

ROOT="${1:?Usage: detect-patterns.sh <question-bank-root>}"

echo "=== Over-Engineering Pattern Detection ==="
echo ""

find "$ROOT" -name "solution.js" -type f | sort | while read -r f; do
  rel="${f#$ROOT/}"
  issues=""

  # Pattern 1: Single-use helper functions (invokeFunc, startTimer, leadingEdge, trailingEdge, etc.)
  helpers=$(grep -oE '\b(invokeFunc|startTimer|leadingEdge|trailingEdge|remainingWait|handleEdge|processItem|normalizeArgs)\b' "$f" | sort -u || true)
  if [ -n "$helpers" ]; then
    for h in $helpers; do
      count=$(grep -c "\b${h}\b" "$f" || true)
      if [ "$count" -le 2 ]; then
        issues="${issues}\n  ⚠️  Helper '${h}' used only ${count}x — consider inlining"
      else
        issues="${issues}\n  🟡 Helper '${h}' used ${count}x — verify necessity"
      fi
    done
  fi

  # Pattern 2: Result tracking without return requirement
  if grep -qE 'let result\b|result = fn\.apply' "$f" && ! grep -qiE 'return.*value|返回.*值|get.*result' "$f"; then
    issues="${issues}\n  ⚠️  Tracks 'result' variable — question may not require return values"
  fi

  # Pattern 3: Excessive function count relative to line count
  lines=$(wc -l < "$f" | tr -d ' ')
  funcs=$(grep -c '\bfunction\b' "$f" || true)
  if [ "$lines" -gt 0 ] && [ "$funcs" -gt 0 ]; then
    ratio=$((lines / funcs))
    if [ "$ratio" -lt 15 ] && [ "$lines" -gt 50 ]; then
      issues="${issues}\n  ⚠️  Low lines/function ratio (${ratio}) — too many small helpers?"
    fi
  fi

  # Pattern 4: lodash-style naming conventions
  if grep -qE '\bdebounce\.debounced\b|\bthrottle\.throttled\b|function debounced\(|function throttled\(' "$f"; then
    if grep -qE '\b(cancel|flush)\b' "$f"; then
      : # expected
    fi
  fi

  # Pattern 5: Separate internal classes for simple logic
  class_count=$(grep -c '^\s*class ' "$f" || true)
  if [ "$class_count" -gt 1 ] && [ "$lines" -lt 150 ]; then
    issues="${issues}\n  ⚠️  ${class_count} classes in ${lines} lines — consider flattening"
  fi

  # Output
  if [ -n "$issues" ]; then
    echo "── $rel ──"
    echo -e "$issues"
    echo ""
  fi
done

echo "=== Done ==="
