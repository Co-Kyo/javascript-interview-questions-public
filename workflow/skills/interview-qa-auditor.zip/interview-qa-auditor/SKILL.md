---
name: interview-qa-auditor
description: Audit JavaScript interview question bank for quality issues. Checks solution.js files for over-engineering, unrealistic complexity, and misalignment with actual interview expectations. Use when reviewing, improving, or quality-checking hand-written interview question collections (solution.js, question.md, guide.md). Triggers on "audit interview questions", "check solution quality", "review question bank", "题库审查", "检查答案质量".
---

# Interview QA Auditor

Systematically audit a JavaScript interview question bank for quality issues, focusing on whether `solution.js` files match what's actually expected in a 30-45 minute technical interview.

## When to Use

- Reviewing an existing question bank for quality
- Before publishing/sharing interview prep materials
- When a specific solution feels "off" (too complex or too simple)
- Periodic maintenance of a question collection

## Audit Workflow

### Step 1: Inventory Scan

Run the automated scanner to get an overview:

```bash
bash {{SKILL_DIR}}scripts/scan-solutions.sh <question-bank-root>
```

This produces a TSV with: question name, line count, function/class count, complexity flags.

### Step 2: Deep Review (per question)

For each flagged solution, read both `question.md` and `solution.js`, then evaluate against these criteria:

**Red flags (over-engineering):**
- Solution has internal helper functions that could be inlined (`invokeFunc`, `startTimer`, `leadingEdge`, etc.)
- Line count exceeds 2× what a senior dev would write in 30 min
- Abstracts that don't map to any requirement in question.md
- Return value tracking when question doesn't ask for it
- Separate "Edge" functions for what's just an if-branch
- Class-based solutions for what's better as a function (or vice versa)

**Red flags (under-delivering):**
- Missing edge cases explicitly mentioned in question.md
- No `cancel()` when question requires it
- Missing `this`/context binding when wrapping user functions
- No leading/trailing options when question asks for them

**Green flags (interview-realistic):**
- Core logic fits in 15-30 lines
- Helper functions only when they genuinely reduce repetition across 3+ call sites
- Clear variable naming that reads like pseudocode
- Edge cases handled inline rather than in separate abstractions

### Step 3: Generate Report

Produce a structured report (see `references/audit-template.md`) with:
- Overall score per question (🟢 / 🟡 / 🔴)
- Specific issues with line references
- Suggested "interview-realistic" rewrite outline (not full code, just structure)

### Step 4: Rewrite (optional)

If user requests, rewrite a flagged solution to be interview-realistic:
- Target: 15-40 lines for most questions
- Preserve all functional requirements from question.md
- Inline helpers unless they're used 3+ times
- Keep the same API surface (function signature, options, return value)

## Output Format

Default output: markdown report to stdout. If user specifies a file path, write there.

## Key Principle

> A good interview solution demonstrates understanding, not library-grade completeness.
> The goal is "clear, correct, covers edge cases" — not "production-ready lodash clone."
