# Audit Report Template

## Summary

| # | Question | Lines | Funcs | Complexity | Score | Notes |
|---|----------|-------|-------|------------|-------|-------|
| 01 | call-apply-bind | 57 | 3 | medium | 🟡 | ... |

## Per-Question Detail

### 🟢/🟡/🔴 XX-question-name

**File:** `solution.js` (N lines, M functions)

**Question requirements** (from question.md):
- requirement 1
- requirement 2

**Issues found:**
1. 🔴/🟡 Issue description (line X-Y)
2. ...

**Interview-realistic structure:**
```
function mainFn(params) {
  // core logic (N lines)
  // edge cases inline
}
mainFn.cancel = function() { ... }
```

**Verdict:** [One-line summary]

---

## Over-Engineering Patterns Found

### Pattern: Unnecessary Internal Helpers
- Count: N solutions affected
- Examples: `invokeFunc()`, `startTimer()`, `leadingEdge()`
- Fix: Inline the logic unless used 3+ times

### Pattern: Return Value Tracking
- Count: N solutions affected
- Examples: `let result; ... result = fn.apply(...); return result;`
- Fix: Remove unless question explicitly asks for return value

### Pattern: Excessive Abstraction Layers
- Count: N solutions affected
- Examples: Separate class for what's a 5-line function
- Fix: Flatten to single function or minimal class

## Recommendations

1. ...
2. ...
3. ...
