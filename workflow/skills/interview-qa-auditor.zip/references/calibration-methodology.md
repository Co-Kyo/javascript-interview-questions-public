# 题库校准方法论

> 针对本题库（javascript-interview-questions-public）的 solution.js 面试合理性校准。
> 核心问题：**这些代码看起来像面试现场写的吗？**

---

## 诊断框架：6 种偏离模式

每道题的 solution.js 都可以用以下 6 个维度扫描。命中任何一个，就意味着偏离了面试场景。

### 模式 1：库内核移植

**症状**：代码结构直接照搬知名库的内部实现，把库的分解方式当作面试写法。

**本题库实例**：
- `03-debounce-throttle`：`invokeFunc`、`startTimer`、`leadingEdge`、`trailingEdge`、`remainingWait` — 这些是 lodash 内部的函数名和拆分方式，不是面试者会自然想到的结构
- `10-retry-backoff`：`attempt(currentAttempt)` 递归 + `Math.pow(backoff, currentAttempt)` — 模仿 axios-retry 的实现

**诊断标准**：
- 函数/变量名与知名库内部命名雷同
- 代码结构与某个库的源码拆分方式一致
- 存在"只有库作者才会考虑"的抽象层次

**面试现场对比**：面试者写 debounce 时，脑子里想的是"闭包存 timer，每次进来 clearTimeout 再 setTimeout"，不会想"我要拆出 leadingEdge 和 trailingEdge 两个阶段函数"。

### 模式 2：规格全量实现

**症状**：题目只要求核心功能，代码却实现了完整规格/标准的全部细节。

**本题库实例**：
- `04-promise`（204行）：实现了完整的 Promise/A+ 规范 — thenable 递归解析、微任务调度、链式 Promise 状态穿透。面试要求的是"手写 Promise 核心"（pending/fulfilled/rejected 状态机 + then/catch），不是通过 A+ 测试套件
- `22-virtual-list`（285行）：包含动态高度、缓冲区、滚动到指定索引、ResizeObserver 监听 — 面试只需要"固定高度 + 可见区域渲染"

**诊断标准**：
- 代码覆盖了标准/规范的边界情况（如 Promise/A+ 2.3 节 thenable 处理）
- 实现了题目未提及的扩展功能
- 行数超过题目要求的核心功能所需行数的 3 倍以上

**面试现场对比**：面试官说"手写 Promise"，期望看到的是 60-80 行的状态机 + then，不是 200 行的 A+ 兼容实现。面试者如果花 30 分钟写 200 行，说明没抓住重点。

### 模式 3：需求外溢

**症状**：实现了题目根本没要求的功能，代码中出现了"幽灵需求"。

**本题库实例**：
- `03-debounce-throttle`：`let result; result = fn.apply(thisArg, args); return result;` — 题目没要求 debounce/throttle 返回被调函数的返回值，但代码做了完整的 result 追踪
- `29-singleton`：提供了 `singleton`、`singletonWithDestroy`、`singletonByKey` 三个变体 — 题目只要求单例模式，代码却预设了"带销毁"和"按 key 缓存"两个扩展场景
- `28-observer-vs-pubsub`：`once()` 方法 — EventBus 实现了 once，但题目只问观察者模式和发布订阅的区别

**诊断标准**：
- 代码中存在 question.md 未提及的功能
- 变量/函数的存在理由是"可能需要"而非"题目要求"
- 注释或变量名暗示了题目范围外的考量

**面试现场对比**：面试者不会在 30 分钟内主动实现"可能用到"的功能。他们会严格按照题目要求实现，多做一步都是浪费面试时间。

### 模式 4：过度防御

**症状**：大量类型检查、参数校验、错误抛出，把防御性编程当作核心逻辑。

**本题库实例**：
- `28-observer-vs-pubsub`：`typeof observer !== 'object' || typeof observer.update !== 'function'`、`typeof callback !== 'function'`、`throw new TypeError(...)` — 每个方法入口都做类型检查
- `10-retry-backoff`：`typeof fn !== 'function'`、`delay <= 0 || backoff <= 0`、`throw new RangeError(...)` — 参数校验占据了大量行数
- `29-singleton`：`typeof Class !== 'function'` + `throw new TypeError(...)` — 三个变体函数都有相同的防御代码

**诊断标准**：
- 类型检查代码超过总逻辑的 20%
- 存在 `throw new TypeError(...)` 或 `throw new RangeError(...)`
- 防御代码在多个函数中重复出现

**面试现场对比**：面试中写类型检查通常是 1-2 行 `if (!fn) return`，不会构造完整的 Error 对象。面试官考察的是算法思路，不是输入校验。

### 模式 5：函数碎片化

**症状**：一个完整逻辑被拆成多个命名函数，每个函数只有几行，且大多数只被调用一次。

**本题库实例**：
- `03-debounce-throttle`：14 个函数（debounce 7 个 + throttle 7 个），其中 `invokeFunc`、`startTimer`、`leadingEdge`、`trailingEdge` 大部分只在一处调用
- `29-singleton`：9 个函数 — 三个变体函数的核心逻辑几乎相同，只是多了 destroy 或 key 的处理

**诊断标准**：
- 辅助函数只被调用 1 次（应该内联）
- 函数名是"阶段名"而非"可复用操作"（如 `leadingEdge` vs `clearTimer`）
- 总函数数 > 行数/15

**面试现场对比**：面试者会写一个主函数，用注释分隔逻辑块，不会把 5 行代码抽成独立函数。只有在 3+ 处重复使用的逻辑才值得抽取。

### 模式 6：Class 膨胀

**症状**：用 class 封装简单逻辑，引入不必要的 OOP 结构。

**本题库实例**：
- `28-observer-vs-pubsub`：3 个 class（Subject、Observer、EventBus），94 行 — Subject 和 EventBus 的核心逻辑各 20 行左右，用 class 的唯一理由是"看起来面向对象"
- `14-lru-cache`：3 个 class（Node、DoublyLinkedList、LRUCache），98 行 — 链表节点和链表本身可以内联到 LRU 中

**诊断标准**：
- class 的方法数 ≤ 3
- class 只被实例化一次
- 用闭包/普通函数可以更简洁地实现

**面试现场对比**：面试中写 Observer 模式，大多数人会写 2 个简洁的对象工厂或闭包，不会定义完整的 class 体系。

---

## 校准标准：面试合理解法的特征

### 行数基准

| 题目类型 | 面试合理行数 | 本题库实际行数 | 偏离度 |
|----------|-------------|---------------|--------|
| debounce/throttle | 25-40 | 153 | 3.8× |
| Promise 核心 | 60-80 | 204 | 2.9× |
| 虚拟列表 | 60-100 | 285 | 3.2× |
| 分片上传 | 60-100 | 168 | 1.9× |
| 事件委托 | 20-30 | 28 | ✅ |
| 列表转树 | 20-30 | 27 | ✅ |
| 柯里化 | 15-25 | 16 | ✅ |

### 结构基准

面试合理解法的结构特征：
1. **一个主函数**，用注释分隔逻辑块
2. **闭包管理状态**，不用 class 封装
3. **内联边界处理**，不做独立函数
4. **只实现题目要求的功能**，不做"可能需要"的扩展
5. **变量命名直观**，读起来像伪代码

### 代码密度基准

| 指标 | 面试合理 | 过度工程化 |
|------|---------|-----------|
| 行/函数 | 15-40 | < 15 |
| 函数数（<60行题） | 1-3 | > 5 |
| 类型检查占比 | < 10% | > 20% |
| 辅助函数只用1次 | 0 | > 2 |

---

## 校准流程

### Step 1: 扫描诊断

对每道题的 solution.js，用 6 种模式逐一检查：

```
命中模式数:
0 → 🟢 面试合理
1 → 🟡 轻微偏离，看严重程度
2+ → 🔴 需要重写
```

### Step 2: 定位核心偏离

如果命中多个模式，找出**最主要的偏离**（即"最不像面试写法"的特征）。

优先级排序：
1. 库内核移植 > 2. 规格全量实现 > 3. 需求外溢 > 4. 过度防御 > 5. 函数碎片化 > 6. Class膨胀

### Step 3: 生成校准方案

针对主要偏离，给出具体的重写指引：

**示例 — debounce/throttle**：
- 主要偏离：库内核移植（模式1）+ 函数碎片化（模式5）+ 需求外溢（模式3）
- 校准方案：
  - 删除所有 lodash 风格的内部函数（invokeFunc, startTimer, leadingEdge, trailingEdge, remainingWait）
  - 用一个 debounced 函数 + 闭包变量实现全部逻辑
  - 删除 result 追踪（题目未要求返回值）
  - 目标：30-35 行含 cancel + leading/trailing

**示例 — Promise**：
- 主要偏离：规格全量实现（模式2）
- 校准方案：
  - 删除 thenable 递归解析（Promise/A+ 2.3 节）
  - 保留：pending/fulfilled/rejected 状态机 + then + catch
  - 链式 then 可以简化为同步调度（面试中说明"真实实现用微任务"即可）
  - 目标：60-80 行

### Step 4: 验证校准结果

重写后的代码需要通过：
1. 原有 test.js 的所有测试用例
2. 行数在合理区间内
3. 函数数 ≤ 行数/15
4. 不存在 6 种偏离模式中的任何一种
