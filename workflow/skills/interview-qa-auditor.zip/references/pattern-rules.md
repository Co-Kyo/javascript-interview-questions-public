# 偏离模式检查规则（可执行版)

> 每条规则都是具体的 pattern 匹配。agent 执行时：grep 命中 = 该模式触发。
> 不需要"理解"代码，只需要模式匹配。

---

## 模式 1：库内核移植

### 检查规则

对 solution.js 执行以下 grep，命中任一即触发：

```bash
# lodash debounce/throttle 内部函数名
grep -cE '\b(invokeFunc|startTimer|leadingEdge|trailingEdge|remainingWait|debounced|throttled)\b' solution.js

# lodash 内部变量名
grep -cE '\b(lastArgs|lastThis|lastCallTime|timerId)\b' solution.js

# axios-retry 风格
grep -cE '\b(attempt|currentAttempt|retryCount)\b' solution.js
```

### 判定

| 命中数 | 判定 |
|--------|------|
| 0 | 不触发 |
| 1-2 | 🟡 可能巧合，看上下文 |
| 3+ | 🔴 确认触发 |

### 已知库内核映射（本题库专用）

| 题目 | 来源库 | 特征 pattern |
|------|--------|-------------|
| 03-debounce-throttle | lodash | invokeFunc, startTimer, leadingEdge, trailingEdge, remainingWait |
| 10-retry-backoff | axios-retry | attempt(currentAttempt) 递归 |

---

## 模式 2：规格全量实现

### 检查规则

```bash
# 行数超标检查（对比基准）
lines=$(wc -l < solution.js)
# 基准：question.md 中"题目要求"的条目数 × 20 行/条目
# 如果 lines > 条目数 × 30 → 触发

# Promise/A+ 特征
grep -cE '\b(thenable|resolvePromise|PromiseResolution)\b' solution.js

# 过多功能检查：solution.js 中有 question.md 未提及的功能
# 需要人工对比，无法纯 grep
```

### 判定

| 条件 | 判定 |
|------|------|
| 行数 > 题目要求条目数 × 30 | 🔴 |
| 包含标准规范术语（thenable, resolvePromise） | 🔴 |
| 实现了题目未提及的功能（人工确认） | 🟡→🔴 |

---

## 模式 3：需求外溢

### 检查规则

```bash
# 返回值追踪（题目没要求返回值时）
grep -cE '\bresult\s*=\s*fn\.apply\b' solution.js
grep -cE '\breturn\s+result\b' solution.js

# 多变体检查（题目只要求1个实现，代码给了多个）
# 数一下 solution.js 中有几个 module.exports 的独立功能
grep -cE '^function\s+\w+' solution.js
# 如果 > 3 且 question.md 只要求 1-2 个 → 触发

# 额外方法检查
grep -cE '\.cancel\s*=|\.flush\s*=|\.destroy\s*=|\.once\s*=' solution.js
# 对比 question.md 是否要求了 cancel/flush/destroy/once
```

### 判定

| 条件 | 判定 |
|------|------|
| 追踪 result 但题目没提返回值 | 🔴 |
| 代码函数数 > 题目要求数 × 2 | 🔴 |
| 实现了题目没提的方法（cancel/flush/destroy/once） | 看情况：cancel 通常是合理的 |

---

## 模式 4：过度防御

### 检查规则

```bash
# 类型检查密度
type_checks=$(grep -cE 'typeof\s+\w+\s*!==|typeof\s+\w+\s*===|instanceof\b' solution.js)
total_lines=$(wc -l < solution.js)
ratio=$((type_checks * 100 / total_lines))

# 抛出 TypeError/RangeError
grep -cE 'throw\s+new\s+(TypeError|RangeError)' solution.js

# 参数校验块
grep -cE 'if\s*\(typeof\s+\w+\s*!==\s*['"'"'"']function' solution.js
```

### 判定

| 条件 | 判定 |
|------|------|
| 类型检查行数 > 总行数 20% | 🔴 |
| throw new TypeError 出现 > 1 次 | 🔴 |
| 每个方法入口都有 typeof 检查 | 🔴 |

---

## 模式 5：函数碎片化

### 检查规则

```bash
# 函数数与行数比
funcs=$(grep -cE '^\s*function\s+\w+' solution.js)
lines=$(wc -l < solution.js)
ratio=$((lines / funcs))

# 单次调用的辅助函数
# 对每个 function 定义，检查它被调用了几次
# 如果定义了但只被调用 1 次 → 应该内联
```

### 判定

| 条件 | 判定 |
|------|------|
| 行/函数比 < 15 且总行数 > 40 | 🔴 |
| 存在只被调用 1 次的辅助函数 | 🟡 |
| 函数名是"阶段名"（leadingEdge, trailingEdge）而非"操作名"（clearTimer） | 🔴 |

---

## 模式 6：Class 膨胀

### 检查规则

```bash
# class 数量
classes=$(grep -cE '^\s*class\s+\w+' solution.js)

# class 方法数（判断是否过度封装）
# 如果 class 只有 2-3 个方法，且只被实例化 1 次 → 不需要 class
```

### 判定

| 条件 | 判定 |
|------|------|
| class 数 > 2 且总行数 < 150 | 🔴 |
| class 方法数 ≤ 3 且只实例化 1 次 | 🟡 |
| 用闭包/函数可以更简洁实现 | 需人工判断 |

---

## 综合判定

对每道题，统计命中模式数：

| 命中模式数 | 综合判定 | 行动 |
|-----------|---------|------|
| 0 | 🟢 面试合理 | 不动 |
| 1（轻度） | 🟡 标记观察 | 记录，不急于改 |
| 1（重度）或 2+ | 🔴 需要重写 | 生成校准方案 |

**重度判定标准**：
- 模式 1 命中 3+ 个 pattern
- 模式 2 行数超标 2.5 倍以上
- 模式 5 行/函数比 < 10
