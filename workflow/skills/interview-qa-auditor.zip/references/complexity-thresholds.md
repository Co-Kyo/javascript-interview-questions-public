# Interview Solution Complexity Thresholds

These are heuristics, not hard rules. Context matters — a virtual DOM diff is naturally longer than a curry function.

## Line Count Guidelines

| Category | Expected Lines | Flag If Over | Context |
|----------|---------------|--------------|---------|
| Simple utility (call/apply/bind, curry, instanceof) | 10-30 | 50 | Single concept |
| Medium utility (debounce/throttle, deep clone, flat) | 20-40 | 60 | Core logic + edge cases |
| Complex utility (Promise, LRU Cache, EventEmitter) | 40-80 | 120 | State machine / data structure |
| Component-level (virtual list, virtual DOM diff) | 60-120 | 180 | Multiple interacting parts |
| Full feature (chunk upload, WebSocket reconnect) | 80-150 | 200 | Includes lifecycle management |

## Function Count Guidelines

| Lines in Solution | Max Internal Helpers | Flag If Over |
|-------------------|---------------------|--------------|
| < 40 | 0-1 | 2 |
| 40-80 | 1-2 | 3 |
| 80-120 | 2-3 | 4 |
| > 120 | 3-4 | 5 |

## Red Flag Indicators

### Definite Over-Engineering
- Helper function used only once (just inline it)
- `invokeFunc` / `startTimer` / `trailingEdge` type names (lodash-style decomposition)
- Tracking `result` across calls when question doesn't require return values
- Separate `Edge` functions for simple if-branches
- Factory pattern for what's a single function

### Likely Over-Engineering
- > 2x the "expected lines" for category
- > 3 internal helper functions for a medium utility
- Abstract base classes or interfaces in JS
- Symbol-based private properties when closures work fine

### Possible But Justified
- State machine pattern (pending/fulfilled/rejected) for Promise
- Doubly-linked list for LRU Cache (vs Map-only solution)
- Event bubbling simulation with DOM tree traversal

## Under-Engineering Indicators

- Missing edge cases from question.md requirements
- No error handling for invalid inputs
- Works for happy path only
- No cancel/cleanup mechanism when question requires it
