#!/bin/bash
# AI Page Tester — Skill Setup Script
# Run once after installing the skill

set -e
SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SKILL_DIR/scripts"

echo "📦 Installing dependencies..."
npm init -y 2>/dev/null
npm install jsdom @playwright/test playwright 2>&1 | tail -3

echo "🌐 Installing Chromium browser..."
npx playwright install chromium 2>&1 | tail -5

echo "✅ AI Page Tester setup complete!"
echo ""
echo "Usage:"
echo "  node $SKILL_DIR/scripts/runner.js <html-file-or-url>"
echo "  node $SKILL_DIR/scripts/dom-analyzer.js <html-file>"
