/**
 * DOM Analyzer — 解析 HTML 页面，自动识别交互测试点
 * 
 * 输入：HTML 文件路径或 URL
 * 输出：结构化的交互元素列表 + 推断的测试用例
 */

const fs = require('fs');
const { JSDOM } = require('jsdom');

// ─── 交互元素识别规则 ───────────────────────────────────────
const SELECTORS = {
  forms: {
    selector: 'form, [role="form"]',
    category: 'form',
    tests: ['submit_valid', 'submit_empty_required', 'validation_messages', 'reset']
  },
  dataTables: {
    selector: 'table, [role="grid"], [role="table"], .data-table, .table',
    category: 'table',
    tests: ['render_rows', 'sort_columns', 'pagination', 'empty_state', 'select_rows']
  },
  modals: {
    selector: 'dialog, .modal, [role="dialog"], .modal-overlay, [data-modal], [aria-modal="true"]',
    category: 'modal',
    tests: ['open_close', 'escape_key', 'backdrop_click', 'focus_trap', 'scroll_lock']
  },
  dropdowns: {
    selector: 'select, [role="listbox"], [role="combobox"], .dropdown, .select',
    category: 'dropdown',
    tests: ['open_options', 'select_option', 'keyboard_nav', 'close_on_outside']
  },
  tabs: {
    selector: '[role="tablist"], .tabs, .tab-bar',
    category: 'tabs',
    tests: ['switch_tabs', 'keyboard_arrows', 'active_state', 'content_render']
  },
  searchInputs: {
    selector: 'input[type="search"], input[placeholder*="搜索"], input[placeholder*="search"], .search-input',
    category: 'search',
    tests: ['input_text', 'clear_input', 'submit_search', 'empty_result']
  },
  filters: {
    selector: '.filter, [data-filter], .filter-bar, .filter-panel',
    category: 'filter',
    tests: ['apply_filter', 'clear_filter', 'multiple_filters', 'reset_filters']
  },
  sortableHeaders: {
    selector: 'th[data-sort], th[aria-sort], .sortable, [role="columnheader"][aria-sort]',
    category: 'sort',
    tests: ['sort_asc', 'sort_desc', 'sort_indicator', 'sort_reset']
  },
  pagination: {
    selector: '.pagination, [aria-label*="pagination"], [aria-label*="分页"], nav[aria-label*="page"]',
    category: 'pagination',
    tests: ['next_page', 'prev_page', 'first_last_page', 'page_size_change']
  },
  buttons: {
    selector: 'button:not([type="submit"]), [role="button"], .btn, .button',
    category: 'button',
    tests: ['click_responsive', 'disabled_state', 'loading_state']
  },
  links: {
    selector: 'a[href]:not([href^="#"]):not([href^="javascript"])',
    category: 'link',
    tests: ['navigation', 'external_link', 'anchor_scroll']
  },
  accordions: {
    selector: '[role="accordion"], .accordion, details, [data-accordion]',
    category: 'accordion',
    tests: ['expand_collapse', 'multiple_expand', 'default_state']
  },
  tooltips: {
    selector: '[data-tooltip], [title], [aria-describedby], .tooltip',
    category: 'tooltip',
    tests: ['show_on_hover', 'hide_on_leave', 'position_correct']
  },
  infiniteScroll: {
    selector: '[data-infinite-scroll], .infinite-scroll, [data-virtual-list]',
    category: 'infinite_scroll',
    tests: ['load_more', 'scroll_trigger', 'loading_indicator', 'end_of_list']
  },
  dragDrop: {
    selector: '[draggable="true"], [data-draggable], .drag-handle, .sortable-item',
    category: 'drag_drop',
    tests: ['drag_start', 'drop_target', 'reorder', 'drag_visual_feedback']
  }
};

// ─── 表单字段深度分析 ──────────────────────────────────────
function analyzeFormFields(formEl) {
  const fields = [];
  const inputs = formEl.querySelectorAll('input, textarea, select');
  
  inputs.forEach(input => {
    const field = {
      tag: input.tagName.toLowerCase(),
      type: input.getAttribute('type') || 'text',
      name: input.getAttribute('name') || '',
      id: input.id || '',
      required: input.hasAttribute('required') || input.getAttribute('aria-required') === 'true',
      placeholder: input.getAttribute('placeholder') || '',
      pattern: input.getAttribute('pattern') || '',
      minLength: input.getAttribute('minlength') || null,
      maxLength: input.getAttribute('maxlength') || null,
      min: input.getAttribute('min') || null,
      max: input.getAttribute('max') || null,
    };

    // 推断验证测试用例
    field.validationTests = [];
    if (field.required) {
      field.validationTests.push('empty_value_rejected');
    }
    if (field.type === 'email') {
      field.validationTests.push('invalid_email_format');
    }
    if (field.type === 'url') {
      field.validationTests.push('invalid_url_format');
    }
    if (field.pattern) {
      field.validationTests.push('pattern_mismatch');
    }
    if (field.minLength) {
      field.validationTests.push('below_min_length');
    }
    if (field.maxLength) {
      field.validationTests.push('exceeds_max_length');
    }
    if (field.type === 'number') {
      field.validationTests.push('non_numeric_input', 'below_min', 'above_max');
    }

    fields.push(field);
  });

  return fields;
}

// ─── 表格结构深度分析 ──────────────────────────────────────
function analyzeTableStructure(tableEl) {
  const headers = [];
  const thElements = tableEl.querySelectorAll('thead th, thead td, tr:first-child th');
  thElements.forEach(th => {
    headers.push({
      text: th.textContent.trim(),
      sortable: th.hasAttribute('data-sort') || 
                th.getAttribute('aria-sort') !== null ||
                th.classList.contains('sortable'),
      sortDirection: th.getAttribute('aria-sort') || null
    });
  });

  const rows = tableEl.querySelectorAll('tbody tr, tr:not(:first-child)');
  const hasPagination = !!tableEl.closest('[class*="table"]')?.querySelector(
    '.pagination, [aria-label*="pagination"]'
  );

  return {
    headers,
    rowCount: rows.length,
    hasPagination,
    hasSelection: !!tableEl.querySelector('input[type="checkbox"], [role="checkbox"]'),
    hasActions: !!tableEl.querySelector('button, a.btn, [role="button"]')
  };
}

// ─── 主分析函数 ─────────────────────────────────────────────
function analyzeHTML(htmlPath) {
  const html = fs.readFileSync(htmlPath, 'utf-8');
  const dom = new JSDOM(html, { url: 'http://localhost' });
  const document = dom.window.document;

  const result = {
    filePath: htmlPath,
    title: document.querySelector('title')?.textContent || '',
    lang: document.documentElement.lang || 'en',
    testPoints: [],
    summary: {}
  };

  // 遍历所有选择器规则
  for (const [key, rule] of Object.entries(SELECTORS)) {
    const elements = document.querySelectorAll(rule.selector);
    elements.forEach((el, index) => {
      const testPoint = {
        id: `${key}_${index}`,
        category: rule.category,
        selector: buildSelector(el, index, rule),
        tests: [...rule.tests],
        element: {
          tag: el.tagName.toLowerCase(),
          id: el.id || null,
          classes: Array.from(el.classList).slice(0, 5),
          text: el.textContent?.trim().substring(0, 100) || '',
          attributes: getRelevantAttributes(el)
        }
      };

      // 深度分析：表单
      if (rule.category === 'form') {
        testPoint.formFields = analyzeFormFields(el);
        testPoint.tests.push(...getFormSpecificTests(testPoint.formFields));
      }

      // 深度分析：表格
      if (rule.category === 'table') {
        testPoint.tableStructure = analyzeTableStructure(el);
      }

      // 深度分析：模态框
      if (rule.category === 'modal') {
        testPoint.hasCloseButton = !!el.querySelector(
          '[aria-label*="close"], .close, .modal-close, button[data-dismiss]'
        );
        testPoint.hasOverlay = el.classList.contains('modal') || !!el.querySelector('.modal-overlay');
      }

      result.testPoints.push(testPoint);
    });
  }

  // 生成摘要
  result.summary = {
    totalTestPoints: result.testPoints.length,
    byCategory: result.testPoints.reduce((acc, tp) => {
      acc[tp.category] = (acc[tp.category] || 0) + 1;
      return acc;
    }, {}),
    totalTests: result.testPoints.reduce((sum, tp) => sum + tp.tests.length, 0),
    complexity: result.testPoints.length > 20 ? 'high' : 
                result.testPoints.length > 10 ? 'medium' : 'low'
  };

  return result;
}

// ─── 辅助函数 ───────────────────────────────────────────────
function buildSelector(el, index, rule) {
  if (el.id) return `#${el.id}`;
  if (el.getAttribute('data-testid')) return `[data-testid="${el.getAttribute('data-testid')}"]`;
  
  // 构建更精确的选择器
  const tag = el.tagName.toLowerCase();
  const classes = Array.from(el.classList).slice(0, 2).map(c => `.${c}`).join('');
  
  if (classes) return `${tag}${classes}`;
  return `${rule.selector}:nth-of-type(${index + 1})`;
}

function getRelevantAttributes(el) {
  const attrs = {};
  const relevant = ['role', 'aria-label', 'aria-describedby', 'data-testid', 
                     'placeholder', 'href', 'type', 'name', 'action', 'method'];
  for (const attr of relevant) {
    const val = el.getAttribute(attr);
    if (val) attrs[attr] = val;
  }
  return attrs;
}

function getFormSpecificTests(fields) {
  const tests = [];
  if (fields.some(f => f.type === 'email')) tests.push('email_validation');
  if (fields.some(f => f.type === 'password')) tests.push('password_masking');
  if (fields.some(f => f.type === 'file')) tests.push('file_upload');
  if (fields.some(f => f.tag === 'select')) tests.push('dropdown_selection');
  if (fields.some(f => f.type === 'date')) tests.push('date_picker');
  if (fields.filter(f => f.required).length > 0) tests.push('required_field_validation');
  return tests;
}

// ─── 导出 ───────────────────────────────────────────────────
module.exports = { analyzeHTML, SELECTORS };

// CLI 直接运行
if (require.main === module) {
  const filePath = process.argv[2];
  if (!filePath) {
    console.error('Usage: node dom-analyzer.js <html-file>');
    process.exit(1);
  }
  const result = analyzeHTML(filePath);
  console.log(JSON.stringify(result, null, 2));
}
