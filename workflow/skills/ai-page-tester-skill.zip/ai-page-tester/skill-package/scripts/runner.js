/**
 * Runner — 编排分析→生成→执行的完整流程
 * 
 * 用法:
 *   node src/runner.js <html-file-or-url> [--serve] [--port 8080] [--report]
 */

const path = require('path');
const fs = require('fs');
const http = require('http');
const { execSync, spawn } = require('child_process');
const { analyzeHTML } = require('./dom-analyzer');
const { generateTestScript } = require('./test-generator');

// ─── 静态文件服务器 ─────────────────────────────────────────
function startServer(rootDir, port = 8765) {
  return new Promise((resolve) => {
    const mimeTypes = {
      '.html': 'text/html', '.js': 'application/javascript',
      '.css': 'text/css', '.json': 'application/json',
      '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml'
    };

    const server = http.createServer((req, res) => {
      let filePath = path.join(rootDir, req.url === '/' ? '/index.html' : req.url);
      const ext = path.extname(filePath);
      const contentType = mimeTypes[ext] || 'application/octet-stream';

      fs.readFile(filePath, (err, content) => {
        if (err) {
          res.writeHead(404);
          res.end('Not found');
        } else {
          res.writeHead(200, { 'Content-Type': contentType });
          res.end(content);
        }
      });
    });

    server.listen(port, () => {
      console.log(`🌐 静态服务器启动: http://localhost:${port}`);
      resolve({ server, port });
    });
  });
}

// ─── 主流程 ─────────────────────────────────────────────────
async function run(target, options = {}) {
  const {
    serve = false,
    port = 8765,
    report = true,
    headed = false,
    timeout = 30000,
    outputDir = path.join(process.cwd(), 'test-output')
  } = options;

  console.log('═══════════════════════════════════════════════');
  console.log('  🔍 AI Page Tester — 前端交互自动化测试');
  console.log('═══════════════════════════════════════════════\n');

  // Step 1: 判断是 URL 还是本地文件
  const isUrl = target.startsWith('http://') || target.startsWith('https://');
  let analyzeTarget = target;
  let serverInfo = null;

  if (!isUrl && serve) {
    // 启动本地服务器
    const rootDir = path.dirname(path.resolve(target));
    serverInfo = await startServer(rootDir, port);
    analyzeTarget = `http://localhost:${port}/${path.basename(target)}`;
  } else if (!isUrl) {
    analyzeTarget = path.resolve(target);
  }

  // Step 2: 分析 DOM
  console.log('📊 Step 1: 分析页面 DOM 结构...');
  let analysis;
  if (isUrl) {
    // 对 URL，用 Playwright 获取 HTML 后分析
    const tempFile = path.join(outputDir, 'page-snapshot.html');
    fs.mkdirSync(outputDir, { recursive: true });
    try {
      const html = execSync(
        `node -e "
          const { chromium } = require('playwright');
          (async () => {
            const browser = await chromium.launch();
            const page = await browser.newPage();
            await page.goto('${target}', { waitUntil: 'networkidle', timeout: 15000 });
            const html = await page.content();
            require('fs').writeFileSync('${tempFile}', html);
            await browser.close();
          })();
        "`,
        { encoding: 'utf-8', timeout: 20000 }
      );
      analysis = analyzeHTML(tempFile);
    } catch (e) {
      console.error('❌ 无法获取页面:', e.message);
      process.exit(1);
    }
  } else {
    analysis = analyzeHTML(analyzeTarget);
  }

  console.log(`   ✅ 找到 ${analysis.summary.totalTestPoints} 个交互测试点`);
  console.log(`   📋 分类: ${JSON.stringify(analysis.summary.byCategory)}`);
  console.log(`   🎯 复杂度: ${analysis.summary.complexity}`);
  console.log(`   📝 预计 ${analysis.summary.totalTests} 项测试\n`);

  // Step 3: 生成测试脚本
  console.log('🔧 Step 2: 生成 Playwright 测试脚本...');
  fs.mkdirSync(outputDir, { recursive: true });
  const testFile = path.join(outputDir, 'generated.spec.js');
  const urlForTest = serve ? analyzeTarget : 
    (isUrl ? target : `file://${path.resolve(target)}`);
  
  generateTestScript(analysis, { 
    url: urlForTest, 
    outputFile: testFile 
  });
  console.log(`   ✅ 测试脚本: ${testFile}\n`);

  // Step 4: 执行测试
  console.log('🚀 Step 3: 执行 Playwright 测试...\n');

  // 写入 playwright 配置
  const configPath = path.join(outputDir, 'playwright.config.js');
  const config = `module.exports = {
  testDir: '${outputDir}',
  timeout: ${timeout},
  use: {
    headless: ${!headed},
    viewport: { width: 1280, height: 720 },
    ignoreHTTPSErrors: true,
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
  },
  reporter: [
    ['list'],
    ${report ? `['html', { outputFolder: '${path.join(outputDir, 'report')}', open: 'never' }]` : ''}
  ],
};`;
  fs.writeFileSync(configPath, config, 'utf-8');

  try {
    execSync(`npx playwright test --config="${configPath}"`, {
      stdio: 'inherit',
      timeout: timeout + 10000,
      cwd: outputDir
    });
    console.log('\n✅ 所有测试通过！');
  } catch (e) {
    console.log('\n⚠️  部分测试失败，请查看报告');
  }

  // 清理
  if (serverInfo) {
    serverInfo.server.close();
  }

  // 输出报告路径
  if (report) {
    console.log(`\n📊 HTML 报告: ${path.join(outputDir, 'report', 'index.html')}`);
  }

  // 输出分析摘要 JSON
  const summaryPath = path.join(outputDir, 'analysis-summary.json');
  fs.writeFileSync(summaryPath, JSON.stringify(analysis, null, 2), 'utf-8');
  console.log(`📋 分析摘要: ${summaryPath}`);

  return analysis;
}

// ─── CLI ────────────────────────────────────────────────────
if (require.main === module) {
  const args = process.argv.slice(2);
  const target = args.find(a => !a.startsWith('--'));
  
  if (!target) {
    console.log(`
用法: node src/runner.js <html-file-or-url> [选项]

选项:
  --serve           启动本地 HTTP 服务器（适用于含 AJAX 的页面）
  --port <port>     服务器端口（默认 8765）
  --headed          有头模式运行浏览器
  --no-report       不生成 HTML 报告
  --timeout <ms>    测试超时时间（默认 30000ms）

示例:
  node src/runner.js ./page.html                    # 测试本地文件
  node src/runner.js ./page.html --serve            # 启动服务器测试
  node src/runner.js https://example.com            # 测试远程 URL
  node src/runner.js ./page.html --headed --report  # 有头模式 + 报告
`);
    process.exit(0);
  }

  const options = {
    serve: args.includes('--serve'),
    port: parseInt(args.find(a => a.startsWith('--port'))?.split('=')[1] || 
           args[args.indexOf('--port') + 1] || '8765'),
    headed: args.includes('--headed'),
    report: !args.includes('--no-report'),
    timeout: parseInt(args.find(a => a.startsWith('--timeout'))?.split('=')[1] || 
             args[args.indexOf('--timeout') + 1] || '30000'),
  };

  run(target, options).catch(err => {
    console.error('❌ 执行失败:', err);
    process.exit(1);
  });
}

module.exports = { run };
