/**
 * Test Generator — 从 DOM 分析结果生成 Playwright 测试脚本
 * 
 * 输入：dom-analyzer 的分析结果
 * 输出：可执行的 Playwright .spec.js 文件
 */

// ─── 测试代码片段模板 ──────────────────────────────────────

const TEMPLATES = {
  // ── 运行时错误检测 ──
  runtimeErrors: (url) => `
  test('页面无 JS 运行时错误', async ({ page }) => {
    const errors = [];
    const consoleErrors = [];
    page.on('pageerror', err => errors.push(err.message));
    page.on('console', msg => {
      if (msg.type() === 'error') consoleErrors.push(msg.text());
    });

    await page.goto('${url}');
    await page.waitForLoadState('networkidle');

    // 执行基本交互以触发潜在错误
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(500);

    expect(errors, \`页面 JS 错误: \${errors.join('\\n')}\`).toHaveLength(0);
    expect(consoleErrors, \`Console 错误: \${consoleErrors.join('\\n')}\`).toHaveLength(0);
  });`,

  // ── 网络请求检测 ──
  networkHealth: (url) => `
  test('网络请求无异常', async ({ page }) => {
    const failedRequests = [];
    const errorResponses = [];

    page.on('requestfailed', req => {
      failedRequests.push(\`\${req.url()} - \${req.failure()?.errorText}\`);
    });
    page.on('response', res => {
      if (res.status() >= 400) {
        errorResponses.push(\`\${res.status()} \${res.url()}\`);
      }
    });

    await page.goto('${url}');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1000);

    expect(failedRequests, \`请求失败: \${failedRequests.join('\\n')}\`).toHaveLength(0);
    // 允许 404 用于 favicon 等非关键资源
    const critical = errorResponses.filter(r => !r.includes('favicon'));
    expect(critical, \`错误响应: \${critical.join('\\n')}\`).toHaveLength(0);
  });`,

  // ── 页面基础检查 ──
  pageBasics: (url, title) => `
  test('页面基础元素完整', async ({ page }) => {
    await page.goto('${url}');
    await page.waitForLoadState('domcontentloaded');

    // 有 title
    ${title ? `await expect(page).toHaveTitle(/${escapeRegex(title)}/i);` : 
              `const title = await page.title(); expect(title.length).toBeGreaterThan(0);`}
    
    // 无明显的空容器（可能是渲染失败）
    const emptyBodies = await page.evaluate(() => {
      return document.body.textContent.trim().length === 0;
    });
    expect(emptyBodies).toBe(false);
  });`,

  // ── 表单测试 ──
  formSubmit: (tp, url) => {
    // 判断表单是否在模态框内
    const isInModal = tp.element?.classes?.some(c => c.includes('modal')) || 
                      tp.selector?.includes('Modal') || tp.selector?.includes('modal');
    const openModal = isInModal ? `
    // 表单在模态框内，先打开模态框
    const openBtn = page.locator('button:has-text("新增"), button:has-text("添加"), button:has-text("Open"), button:has-text("打开"), [data-toggle="modal"]').first();
    if (await openBtn.count() > 0) {
      await openBtn.click();
      await page.waitForTimeout(500);
    }` : '';

    return `
  test('表单: ${tp.id} — 提交与验证', async ({ page }) => {
    await page.goto('${url}');
    ${openModal}
    const form = page.locator('${tp.selector}');
    await expect(form).toBeVisible({ timeout: 5000 }).catch(() => test.skip(true, '表单不可见'));

    // 测试空提交（应有验证提示）
    const submitBtn = form.locator('button[type="submit"], input[type="submit"], button:not([type])').first();
    if (await submitBtn.count() > 0) {
      await submitBtn.click();
      await page.waitForTimeout(300);

      // 检查是否有验证消息
      const hasValidation = await page.evaluate(() => {
        const form = document.querySelector('${tp.selector}');
        return !!form?.querySelector(':invalid, [aria-invalid="true"], .error, .field-error, [role="alert"]');
      });
      ${tp.formFields?.some(f => f.required) ? 
        `expect(hasValidation, '表单应有必填项验证').toBe(true);` : 
        `// 此表单无 required 字段;`}
    }
  });

  test('表单: ${tp.id} — 输入与交互', async ({ page }) => {
    await page.goto('${url}');
    ${openModal}
    const form = page.locator('${tp.selector}');
    await expect(form).toBeVisible({ timeout: 5000 }).catch(() => test.skip(true, '表单不可见'));

    // 逐个填写字段
${(tp.formFields || []).map((f, i) => {
  const sel = f.id ? `#${f.id}` : f.name ? `[name="${f.name}"]` : `${f.tag}:nth-of-type(${i + 1})`;
  const val = getTestValue(f);
  return `    // 填写 ${f.name || f.type || f.tag}
    const field${i} = form.locator('${sel}');
    if (await field${i}.count() > 0) {
      await field${i}.${f.tag === 'select' ? 'selectOption' : 'fill'}('${val}');
    }`;
}).join('\n')}

    // 提交
    const submitBtn = form.locator('button[type="submit"], input[type="submit"], button').first();
    if (await submitBtn.count() > 0) {
      await submitBtn.click();
      await page.waitForTimeout(500);
    }
  });`;
  },

  // ── 表格测试 ──
  dataTable: (tp, url) => `
  test('数据表格: ${tp.id} — 渲染与交互', async ({ page }) => {
    await page.goto('${url}');
    const table = page.locator('${tp.selector}').first();
    await expect(table).toBeVisible();

    // 检查有表头
    const headers = table.locator('th, [role="columnheader"]');
    const headerCount = await headers.count();
    expect(headerCount).toBeGreaterThan(0);

    // 检查有数据行或空状态
    const rows = table.locator('tbody tr, [role="row"]:not(:first-child)');
    const rowCount = await rows.count();
    ${tp.tableStructure?.hasPagination ? 
      `// 表格有分页，检查分页控件
    const pagination = page.locator('.pagination, [aria-label*="pagination"], [aria-label*="分页"]');
    await expect(pagination.first()).toBeVisible();` : ''}

    // 测试排序（如果有的话）
${(tp.tableStructure?.headers || []).filter(h => h.sortable).map((h, i) => `
    // 排序列: ${h.text}
    const sortHeader${i} = table.locator('th:has-text("${escapeRegex(h.text)}")').first();
    if (await sortHeader${i}.count() > 0) {
      await sortHeader${i}.click();
      await page.waitForTimeout(300);
      // 点击两次切换升序/降序
      await sortHeader${i}.click();
      await page.waitForTimeout(300);
    }`).join('')}
  });`,

  // ── 模态框测试 ──
  modal: (tp, url) => `
  test('模态框: ${tp.id} — 打开与关闭', async ({ page }) => {
    await page.goto('${url}');

    // 找到触发模态框的按钮
    const trigger = page.locator('[data-toggle="modal"], [data-target*="modal"], button:has-text("打开"), button:has-text("Open"), button:has-text("新增"), button:has-text("添加")').first();
    if (await trigger.count() === 0) {
      test.skip(true, '未找到模态框触发按钮');
      return;
    }
    await trigger.click();
    await page.waitForTimeout(300);

    const modal = page.locator('${tp.selector}');
    await expect(modal.first()).toBeVisible();

    // 测试 ESC 关闭
    await page.keyboard.press('Escape');
    await page.waitForTimeout(300);

    // 重新打开
    await trigger.click();
    await page.waitForTimeout(300);

    // 测试关闭按钮
${tp.hasCloseButton ? 
    `const closeBtn = modal.locator('[aria-label*="close"], .close, .modal-close, button[data-dismiss]').first();
    if (await closeBtn.count() > 0) {
      await closeBtn.click();
      await page.waitForTimeout(300);
    }` : ''}
  });`,

  // ── 按钮测试（带可见性上下文感知）──
  button: (tp, url) => {
    // 检测元素是否在隐藏容器内（tab panel / modal）
    const needsContext = detectVisibilityContext(tp);
    const openContext = needsContext ? `
    // 元素在隐藏容器内，先切换上下文
${needsContext}` : '';

    return `
  test('按钮: ${tp.element?.text || tp.id} — 交互响应', async ({ page }) => {
    await page.goto('${url}');
    ${openContext}
    const btn = page.locator('${tp.selector}').first();
    
    if (await btn.count() === 0) return;

    // 如果元素不可见，尝试滚动或等待
    const isVisible = await btn.isVisible().catch(() => false);
    if (!isVisible) {
      // 尝试等待可见
      await expect(btn).toBeVisible({ timeout: 3000 }).catch(() => {
        test.skip(true, '元素不可见（可能在隐藏容器中）');
        return;
      });
    }

    const isDisabled = await btn.getAttribute('disabled');
    
    if (!isDisabled) {
      await btn.click();
      await page.waitForTimeout(500);
    }
  });`;
  },

  // ── 下拉框测试（带可见性上下文感知）──
  dropdown: (tp, url) => {
    const needsContext = detectVisibilityContext(tp);
    const openContext = needsContext ? `
    // 元素在隐藏容器内，先切换上下文
${needsContext}` : '';

    return `
  test('下拉框: ${tp.id} — 选项选择', async ({ page }) => {
    await page.goto('${url}');
    ${openContext}
    const dropdown = page.locator('${tp.selector}').first();
    if (await dropdown.count() === 0) return;

    const isVisible = await dropdown.isVisible().catch(() => false);
    if (!isVisible) {
      await expect(dropdown).toBeVisible({ timeout: 3000 }).catch(() => {
        test.skip(true, '元素不可见（可能在隐藏容器中）');
        return;
      });
    }

    // 如果是原生 select
    const tagName = await dropdown.evaluate(el => el.tagName.toLowerCase());
    if (tagName === 'select') {
      const options = await dropdown.locator('option').all();
      if (options.length > 1) {
        await dropdown.selectOption({ index: 1 });
        await page.waitForTimeout(300);
      }
    } else {
      // 自定义下拉框
      await dropdown.click();
      await page.waitForTimeout(300);
      const options = page.locator('[role="option"], .dropdown-item, li');
      if (await options.count() > 0) {
        await options.first().click();
        await page.waitForTimeout(300);
      }
    }
  });`;
  },

  // ── Tab 页测试 ──
  tabs: (tp, url) => `
  test('Tab 页: ${tp.id} — 切换', async ({ page }) => {
    await page.goto('${url}');
    const tablist = page.locator('${tp.selector}').first();
    if (await tablist.count() === 0) return;

    const tabs = tablist.locator('[role="tab"], button, a');
    const tabCount = await tabs.count();
    expect(tabCount).toBeGreaterThan(0);

    // 逐个切换 tab
    for (let i = 0; i < Math.min(tabCount, 5); i++) {
      await tabs.nth(i).click();
      await page.waitForTimeout(300);
      
      // 检查对应面板是否显示
      const tabId = await tabs.nth(i).getAttribute('aria-controls');
      if (tabId) {
        const panel = page.locator(\`#\${tabId}\`);
        await expect(panel).toBeVisible();
      }
    }
  });`,

  // ── 搜索测试 ──
  search: (tp, url) => `
  test('搜索: ${tp.id} — 输入与结果', async ({ page }) => {
    await page.goto('${url}');
    const searchInput = page.locator('${tp.selector}').first();
    if (await searchInput.count() === 0) return;

    await expect(searchInput).toBeVisible();

    // 输入搜索词
    await searchInput.fill('test');
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);

    // 清空搜索
    await searchInput.fill('');
    await page.keyboard.press('Enter');
    await page.waitForTimeout(500);
  });`,

  // ── 筛选测试 ──
  filter: (tp, url) => `
  test('筛选: ${tp.id} — 筛选交互', async ({ page }) => {
    await page.goto('${url}');
    const filterPanel = page.locator('${tp.selector}').first();
    if (await filterPanel.count() === 0) return;

    // 查找筛选控件
    const selects = filterPanel.locator('select');
    const checkboxes = filterPanel.locator('input[type="checkbox"]');
    const radios = filterPanel.locator('input[type="radio"]');

    // 测试下拉筛选
    if (await selects.count() > 0) {
      const firstSelect = selects.first();
      const options = await firstSelect.locator('option').all();
      if (options.length > 1) {
        await firstSelect.selectOption({ index: 1 });
        await page.waitForTimeout(500);
      }
    }

    // 测试复选框筛选
    if (await checkboxes.count() > 0) {
      await checkboxes.first().click();
      await page.waitForTimeout(500);
    }

    // 查找清除按钮
    const clearBtn = filterPanel.locator('button:has-text("清除"), button:has-text("重置"), button:has-text("Clear"), button:has-text("Reset")').first();
    if (await clearBtn.count() > 0) {
      await clearBtn.click();
      await page.waitForTimeout(300);
    }
  });`,

  // ── 分页测试 ──
  pagination: (tp, url) => `
  test('分页: ${tp.id} — 翻页', async ({ page }) => {
    await page.goto('${url}');
    const pagination = page.locator('${tp.selector}').first();
    if (await pagination.count() === 0) return;

    await expect(pagination).toBeVisible();

    // 点击下一页
    const nextBtn = pagination.locator('[aria-label*="next"], [aria-label*="下一页"], .next, button:has-text("›"), button:has-text("Next")').first();
    if (await nextBtn.count() > 0 && !(await nextBtn.getAttribute('disabled'))) {
      await nextBtn.click();
      await page.waitForTimeout(500);
    }

    // 点击上一页
    const prevBtn = pagination.locator('[aria-label*="prev"], [aria-label*="上一页"], .prev, button:has-text("‹"), button:has-text("Previous")').first();
    if (await prevBtn.count() > 0 && !(await prevBtn.getAttribute('disabled'))) {
      await prevBtn.click();
      await page.waitForTimeout(500);
    }
  });`,
};

// ─── 主生成函数 ─────────────────────────────────────────────
function generateTestScript(analysis, options = {}) {
  const { url = analysis.filePath, outputFile } = options;
  const fileUrl = url.startsWith('http') ? url : `file://${require('path').resolve(url)}`;

  let imports = `const { test, expect } = require('@playwright/test');`;

  let testCases = [];

  // 基础测试（始终包含）
  testCases.push(TEMPLATES.runtimeErrors(fileUrl));
  testCases.push(TEMPLATES.networkHealth(fileUrl));
  testCases.push(TEMPLATES.pageBasics(fileUrl, analysis.title));

  // 按类别生成测试
  for (const tp of analysis.testPoints) {
    switch (tp.category) {
      case 'form':
        testCases.push(TEMPLATES.formSubmit(tp, fileUrl));
        break;
      case 'table':
        testCases.push(TEMPLATES.dataTable(tp, fileUrl));
        break;
      case 'modal':
        testCases.push(TEMPLATES.modal(tp, fileUrl));
        break;
      case 'button':
        testCases.push(TEMPLATES.button(tp, fileUrl));
        break;
      case 'dropdown':
        testCases.push(TEMPLATES.dropdown(tp, fileUrl));
        break;
      case 'tabs':
        testCases.push(TEMPLATES.tabs(tp, fileUrl));
        break;
      case 'search':
        testCases.push(TEMPLATES.search(tp, fileUrl));
        break;
      case 'filter':
        testCases.push(TEMPLATES.filter(tp, fileUrl));
        break;
      case 'pagination':
        testCases.push(TEMPLATES.pagination(tp, fileUrl));
        break;
      // link, accordion, tooltip, infinite_scroll, drag_drop, sort
      // 默认生成基础可点击测试
      default:
        if (!['sort'].includes(tp.category)) {
          testCases.push(TEMPLATES.button(tp, fileUrl));
        }
    }
  }

  const script = `${imports}

/**
 * 自动生成的页面交互测试
 * 源文件: ${analysis.filePath}
 * 测试点: ${analysis.summary.totalTestPoints} 个
 * 测试用例: ${analysis.summary.totalTests} 项
 * 生成时间: ${new Date().toISOString()}
 */

test.describe('${analysis.title || '页面交互测试'}', () => {
${testCases.join('\n')}
});
`;

  if (outputFile) {
    require('fs').writeFileSync(outputFile, script, 'utf-8');
  }

  return script;
}

// ─── 辅助函数 ───────────────────────────────────────────────
function detectVisibilityContext(tp) {
  // 分析元素的 DOM 路径，判断是否在 tab panel 或 modal 内
  const classes = tp.element?.classes || [];
  const selector = tp.selector || '';
  
  // 检查是否在 tab panel 中
  // 通过分析 DOM 层级关系推断
  // 如果元素 ID 包含 settings/panel 等关键词，可能在隐藏 tab 中
  const hiddenTabIndicators = ['settings', 'config', 'advanced', 'panel-stats', 'panel-settings'];
  const isInHiddenTab = hiddenTabIndicators.some(ind => 
    selector.toLowerCase().includes(ind) || 
    tp.element?.id?.toLowerCase().includes(ind)
  );
  
  // 检查是否在模态框中
  const isInModal = selector.includes('Modal') || selector.includes('modal') ||
    classes.some(c => c.includes('modal'));
  
  if (isInHiddenTab) {
    return `    // 先切换到对应的 tab 面板
    const tabTrigger = page.locator('[role="tab"][data-tab="settings"], [role="tab"]:has-text("设置")').first();
    if (await tabTrigger.count() > 0) {
      await tabTrigger.click();
      await page.waitForTimeout(500);
    }`;
  }
  
  if (isInModal) {
    return `    // 先打开模态框
    const openBtn = page.locator('button:has-text("新增"), button:has-text("添加"), button:has-text("Open"), [data-toggle="modal"]').first();
    if (await openBtn.count() > 0) {
      await openBtn.click();
      await page.waitForTimeout(500);
    }`;
  }
  
  return '';
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function getTestValue(field) {
  switch (field.type) {
    case 'email': return 'test@example.com';
    case 'password': return 'Test1234!';
    case 'tel': return '13800138000';
    case 'number': return '42';
    case 'url': return 'https://example.com';
    case 'date': return '2025-01-15';
    case 'time': return '14:30';
    case 'color': return '#ff0000';
    default: return 'test value';
  }
}

module.exports = { generateTestScript, TEMPLATES };
