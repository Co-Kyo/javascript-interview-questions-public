---
name: ai-page-tester
description: 自动化前端页面交互测试。当用户要求"测试页面"、"检查交互"、"验证DOM行为"、"测试表单/表格/模态框"、"页面质量检查"、"运行E2E测试"、"test page"、"check interactions"、"E2E test"时使用。也可用于AI Agent生成的HTML页面质量验证。支持自动分析DOM结构、生成Playwright测试脚本、检测运行时错误和网络异常。
---

# AI Page Tester

自动分析 HTML 页面的交互元素，生成 Playwright 测试脚本并执行。

## TL;DR

```bash
# 完整测试（分析 + 生成 + 执行）
node <skill-dir>/scripts/runner.js <html文件或URL> [--serve]

# 仅分析交互点
node <skill-dir>/scripts/dom-analyzer.js <html文件>
```

输出：`test-output/generated.spec.js`（测试脚本）、`test-output/analysis-summary.json`（分析摘要）。

## 工作流程

```
用户页面 → DOM 分析 → 测试点识别 → 测试脚本生成 → Playwright 执行 → 结果报告
    ↓                         ↓                                    ↓
  读取HTML              识别交互元素                          输出通过/失败
  (jsdom)            (表单/表格/模态框等)                   读取报告定位问题
```

## 使用方式

### 1. 测试本地 HTML 文件

```bash
cd <skill-dir>
node scripts/runner.js <html文件路径>
```

### 2. 测试远程 URL

```bash
cd <skill-dir>
node scripts/runner.js https://example.com
```

### 3. 含 AJAX 请求的页面（需 HTTP 服务器）

```bash
cd <skill-dir>
node scripts/runner.js <html文件路径> --serve
```

### 4. 仅分析 DOM（不执行测试）

```bash
cd <skill-dir>
node scripts/dom-analyzer.js <html文件路径>
```

## 输出文件

| 文件 | 说明 |
|------|------|
| `test-output/generated.spec.js` | 自动生成的 Playwright 测试脚本 |
| `test-output/analysis-summary.json` | DOM 分析摘要（交互点分类、数量） |
| `test-output/report/index.html` | HTML 测试报告（如有） |

### 输出示例（analysis-summary.json）

```json
{
  "title": "用户管理系统",
  "summary": {
    "totalTestPoints": 20,
    "byCategory": { "form": 1, "table": 1, "modal": 2, "button": 5 },
    "totalTests": 81,
    "complexity": "medium"
  }
}
```

## 自动检测的交互类型

- 表单：提交验证、必填项、邮箱/手机号格式
- 数据表格：排序、分页、筛选、空状态
- 模态框：ESC关闭、背景点击、焦点陷阱
- Tab页：切换、面板联动
- 下拉框：选项选择、键盘导航
- 搜索框：输入、清空、回车提交
- 分页：上下页、页码切换
- 按钮：点击响应、禁用状态

## 运行时检测

- JS 运行时错误（pageerror + console.error）
- 网络请求异常（4xx/5xx、请求失败）
- DOM 节点泄漏（操作前后对比）

## 测试失败处理

当测试有失败项时，按以下步骤处理：

1. **读取失败用例**：查看 `test-output/generated.spec.js` 中失败的 test 名称
2. **定位问题**：失败的测试名会说明是哪个交互点（如"表单: forms_0 — 提交与验证"）
3. **修复页面**：根据失败原因修改 HTML/JS 代码
4. **重新测试**：再次运行 runner.js 验证修复
5. **跳过的用例**：标记为 skipped 的通常是元素在隐藏容器中（如未激活的 Tab 面板），属正常行为

## 常见问题排查

| 问题 | 原因 | 解决 |
|------|------|------|
| `Executable doesn't exist` | Playwright 浏览器未安装 | 运行 `npx playwright install chromium` |
| `Cannot find module 'jsdom'` | 依赖未安装 | 在 skill 目录运行 `npm install jsdom` |
| 所有测试 skipped | 页面元素在隐藏容器中 | 检查页面是否有 Tab/Modal 需先激活 |
| 网络请求 404 | 静态资源路径错误 | 使用 `--serve` 模式启动 HTTP 服务器 |
| 表单测试失败 | 模态框未打开 | 确认触发按钮的文本匹配（新增/添加/Open） |

## 依赖

- Node.js >= 18
- Playwright + Chromium（`npx playwright install chromium`）
- jsdom（`npm install jsdom`）

首次使用需安装依赖：
```bash
cd <skill-dir>/scripts && npm install jsdom @playwright/test && npx playwright install chromium
```

## Agent 工作流集成

Agent 生成 HTML 页面后自动调用验证：

```bash
# 完整流程：分析 + 生成 + 执行
node <skill-dir>/scripts/runner.js ./page.html --serve

# 仅分析（快速检查有哪些交互点）
node <skill-dir>/scripts/dom-analyzer.js ./page.html
```

### 结果处理流程

1. **运行测试** → 获取结果摘要
2. **展示给用户** → "X 个测试通过，Y 个失败，Z 个跳过"
3. **如有失败** → 读取 `generated.spec.js` 定位问题，提出修复建议，**等用户确认后再修复**
4. **全部通过** → 交付页面，询问用户是否需要更深入的测试（如无障碍、性能）
5. **用户确认修复后** → 重新运行测试，对比前后结果
