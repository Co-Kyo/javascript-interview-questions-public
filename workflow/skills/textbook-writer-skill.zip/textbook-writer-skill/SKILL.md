---
name: textbook-writer
description: "Rewrite expert-style technical explanations into learner-guided teaching material with progressive concept building. Outputs guide.md (text script) + guide.html (interactive learning experience — the effect amplifier). Use when the user provides an explanation.md, technical notes, or any dense documentation and asks to make it understandable for beginners, create a guide, rewrite for learners, or fix reading comprehension issues in technical content. Triggers on phrases like \"看不懂\", \"读不进去\", \"初学者\", \"guide\", \"引导式\", \"教材\", \"改写\", \"降维讲解\", \"交互式\", \"可视化\", \"系列\", \"拆分\", \"太长了\", \"概念太多\"."
---

# Textbook Writer

Rewrite expert notes into guided tutorials. Two deliverables, one goal: **让读者真正学会**。

- **`guide.md`** — 文字引导脚本（内容骨架，Stage 3 产出）
- **`guide.html`** — 交互式学习体验（效果放大器，Stage 4 产出）

guide.md 是脚手架，guide.html 是教学体验本身。不是"文字版 + 可视化版"的并列关系，而是"剧本 + 舞台演出"的递进关系。

## Pipeline

Run these 6 stages in order. Each stage has a verifiable output.

### Stage 1: Concept Dependency Graph

**提取方法**（按以下 4 类逐项扫描源文档）：

1. **术语**：技术名词首次出现即为一个概念（如"闭包"、"原型链"、"this 绑定"）
2. **代码模式**：独立的代码技巧（如"用 Symbol 做临时属性键"、"Object.create 切断引用"）
3. **API/方法**：被实现或调用的原生 API（如 `Function.prototype`、`instanceof`、`Reflect.construct`）
4. **设计决策**：需要理解"为什么"的选择（如"为什么用 Symbol 不用字符串"、"为什么 new 优先级高于 bind"）

**依赖判断**：对每对概念 (A, B)，问"不理解 A 能理解 B 吗？"如果不能，画边 A → B。

**验证**：
- 无环（如果 A→B→C→A，说明依赖关系分析有误，重新检查）
- 无孤立节点（每个概念至少有一条边连接到最终实现）
- 每个节点到最终实现有路径

**输出**：概念 DAG（列出所有节点 + 边）

**⏸ 检查点 1**：展示概念 DAG 给用户确认后再进入 Stage 2。如果用户指出遗漏或多余的概念，修正 DAG 后继续。

> **自动模式**：批量处理或子 agent 执行时，跳过人工确认，直接进入 Stage 2。在最终汇报中标注"跳过检查点"。

### Stage 1.5: Series Detection（系列检测）

分析 Stage 1 的概念 DAG，判断输出应该是**单篇 guide** 还是**guide 系列**。

**核心判断：概念 DAG 是否可拆分为多个密集子图。**

有些题的背景很复杂——概念分属多个独立领域，每个领域自身有完整的依赖链。硬塞进一篇 guide 会导致：步骤过多（>15 步认知负担重）、不同领域频繁跳转（读者上下文切换成本高）、每步密度被迫压缩（讲不透）。正确的做法是拆成系列，每篇聚焦一个领域。

**检测算法：**

1. **计算弱连通分量**：在 DAG 上去掉方向，找连通子图
2. **评估分量密度**：对每个弱连通分量，计算 density = 边数 / 节点数
   - density ≥ 1.0 → 密集（概念间依赖紧密，不宜再拆）
   - density < 1.0 → 稀疏（概念间依赖松散，可能是多个子领域的拼合）
3. **评估分量间耦合度**：统计跨分量的边数（原图方向边）
4. **决策**：

| 信号 | 阈值 | 含义 |
|------|------|------|
| 概念总数 > 20 | 倾向拆 | 一篇装不下 |
| 弱连通分量 ≥ 2 且分量间边 < 3 | 拆 | 领域间弱耦合，天然可分 |
| 任意分量 density < 1.0 | 可能需要子拆 | 稀疏分量可能仍可进一步拆分 |
| 拓扑排序预估步数 > 15 | 拆 | 认知负担过重 |
| 最大概念入度 > 5 | 注意 | "枢纽概念"可能是系列分界点 |

**决策结果：**

- **单篇模式**（1 个密集连通分量，或分量间紧密耦合）：走现有 Stage 2-5 流程
- **系列模式**（2+ 个弱耦合密集分量）：
  1. 每个分量作为一个独立的"分册"，各自走 Stage 2-5
  2. 分册按依赖拓扑顺序**串行**执行（后续分册可能需要引用前序分册的结论，并行会丢失上下文）
  3. 按分量间依赖边确定分册阅读顺序（被依赖的分册排前面）
  4. 额外生成 `series.md`（系列索引）
  5. 每个分册执行时，guide-template.md 中的"前置知识"区域填写前序分册的核心结论（1-2 句话），避免读者跳转

**分册命名规则：**
- 格式：`{NN}-{英文短横线命名}`，如 `01-this-binding`、`02-prototype-chain`
- 命名取自分册核心概念中入度最高（最枢纽）的概念，转英文 kebab-case
- 编号按分册间依赖拓扑顺序，被依赖的排前面
- 如果两个分册互不依赖，按概念数从多到少编号

**系列模式输出结构：**

```
{题目目录}/
├── series.md           # 系列索引
├── 01-{分册名}/
│   ├── guide.md
│   └── guide.html
├── 02-{分册名}/
│   ├── guide.md
│   └── guide.html
└── ...
```

**series.md 必须包含：**
1. 系列标题 + 一句话总述
2. 为什么拆成系列（列出各分量的核心主题和边界）
3. 分册阅读顺序 + 依赖关系图（ASCII 或 Mermaid）
4. 每个分册的一句话摘要

**验证：**
- 每个分册的概念集完整（分册内的依赖链闭环，无需跨分册跳转）
- 分册间依赖是单向的（不存在循环依赖）
- 每个分册概念数 ≤ 15（保证单篇可读性；如果拆分后仍有分册 >15，在分册内找入度最高节点为分割点进一步二分，直到每册 ≤15）
- 所有分册概念数之和 = Stage 1 概念总数（无遗漏无重复）

**⏸ 检查点 1.5**：展示系列检测结果给用户确认。用户可以：
- 同意拆分方案
- 要求合并某些分册
- 要求调整分册边界
- 要求从系列模式改为单篇模式（强制合并）

> **自动模式**：批量处理或子 agent 执行时，跳过人工确认，按算法结果执行。在最终汇报中标注"跳过检查点 1.5"。

**系列模式下的检查点策略**：
- 非批量模式：每个分册的 Stage 2（拓扑排序）完成后汇报，用户确认分册步骤拆分合理再继续写 guide.md
- 批量模式：所有分册的 Stage 2 统一汇报，一次性确认
- 如果分册数 > 5，自动降级为批量模式检查策略（避免逐册确认导致中断过多）

### Stage 2: Topological Sort + Step Splitting

**拓扑排序算法**（Kahn's）：

1. 计算每个节点的入度（被依赖次数）
2. 入度为 0 的节点 = 第一批可学的概念（无前置依赖）
3. 选一个入度为 0 的节点，加入步骤列表，将其从图中移除（指向的节点入度 -1）
4. 重复步骤 2-3 直到所有节点处理完
5. 如果处理完的数量 ≠ 总节点数，说明有环 → 回 Stage 1 修正

**步骤拆分规则**：
- 每个概念 = 1 步
- 如果一步需要 2+ 个新概念，拆成多步
- 每步代码 ≤ 10 行（例外：最终拼装步骤允许 ≤20 行，因为它是引用前面已学过的代码片段）
- 步骤 N 只使用步骤 1..N-1 中已出现的概念

**验证**：步骤数 = 概念数，入度检查通过

**输出**：有序步骤列表 + 概念-步骤映射表

### Stage 3: Write guide.md

Follow the template in `references/guide-template.md`. Each step has exactly this structure:

```
### Step N: {concept name}
困境 → 思考 → 解法 → 代码 (≤10 lines) → 验证
```

Rules:
- Never introduce a concept without first presenting a problem that needs it
- Explain each term on first appearance
- Show code as incremental diffs, not full rewrites
- Use concrete analogies (daily scene + action mapping)
- Ask a question before revealing each answer

Verify: every step's 困境 naturally emerges from the previous step; zero unexplained terms on first use.

**系列模式下的代码拼接**：每个分册的最终拼装步骤产出的代码片段，合在一起必须等价于 solution.js。具体规则：
- 每个分册的拼装步骤只输出该分册概念域对应的代码片段
- 在最后一个分册的拼装步骤中，将所有分册的代码片段按依赖顺序合并为完整实现
- Stage 5 的 code concatenability 检查在系列模式下针对最终合并结果验证

**⏸ 检查点 2**：展示 guide.md 给用户确认后再进入 Stage 4 构建 HTML。用户可以调整步骤顺序、措辞、代码示例。

> **自动模式**：批量处理或子 agent 执行时，跳过人工确认，直接进入 Stage 4。在最终汇报中标注"跳过检查点"。

### Stage 4: Build guide.html (Effect Amplifier)

基于 guide.md 的内容结构，构建交互式教学 HTML。

**⚠️ 关键规则：使用模板，不要从零写 HTML/CSS/JS。**

1. 读取 `references/html-skeleton.html`，这是完整的 HTML 模板（含所有 CSS + JS）
2. 按 `references/template-usage.md` 的说明，替换 4 个占位符：
   - `__TITLE__` → 页面标题
   - `__SUBTITLE__` → 副标题
   - `__NAV_ITEMS__` → 导航栏锚点（每个 step 一个 `<a>`）
   - `__STEP_SECTIONS__` → 所有步骤内容
3. **不要修改 `<style>` 和 `<script>` 部分**
4. 每个 step 使用固定的 HTML 结构（见 template-usage.md）

**每个 Step 的内容 class：**

| class | 必填 | 说明 |
|-------|------|------|
| `.dilemma` | ✅ | 困境描述 |
| `.think` | ✅ | 引导思考 |
| `.solution` | ✅ | 解法说明 |
| `.analogy` | 选填 | 日常类比 |
| `.warning` | 选填 | 易错点/注意事项 |
| `.code-wrap` | ✅ | 代码块 + 运行按钮 + 输出区 |
| `.question` | 选填 | 面试追问 Q&A |

**代码块格式（固定结构，不要改 class 名）：**

```html
<div class="code-wrap">
  <div class="code-header">
    <span class="code-lang">JavaScript</span>
    <div class="code-actions">
      <button class="btn-copy" onclick="copyCode(this)">复制</button>
      <button class="btn-run" onclick="runCode(this)">运行 ▶</button>
    </div>
  </div>
  <pre><code>// 纯文本代码，不要 HTML 转义</code></pre>
  <div class="output"></div>
</div>
```

**质量标准（Stage 5 验证用）：**
- 所有 guide.md 步骤在 HTML 中都有对应呈现（100% 覆盖）
- 交互元素可操作（点击/编辑/运行均正常）
- 无 console 报错
- HTML 文件大小 ≤ guide.md × 5（避免过度膨胀）
### Stage 5: Verification

Run these checks against both outputs. All must pass.

| Check | Method | Pass criteria |
|-------|--------|---------------|
| Concept coverage | List all concepts from source → confirm each has a dedicated step | 100% |
| Dependency order | For each step B, verify all B's prerequisites appeared in earlier steps | 0 violations |
| Density | Count code lines and new terms per step | ≤10 lines（最终拼装 ≤20 行），≤1 term |
| Code concatenability | Concatenate all step code snippets → compare with solution.js | Functionally equivalent |
| HTML coverage | Every guide.md step has a corresponding section/interaction in guide.html | 100% |
| HTML interactivity | Open guide.html in browser → all interactive elements functional | 0 broken |
| HTML zero-dep | No external CDN links, no npm imports, no fetch to external URLs | 0 violations |
| 系列分册交叉引用 | 系列模式下，每个分册 guide.html 的前置知识区域链接可点击跳转到前序分册 | 0 broken links |

**⏸ 最终汇报（必须执行，自动模式不跳过）**：

Stage 5 完成后，向用户汇报以下内容：

```
## 完成报告

| 项目 | 结果 |
|------|------|
| 步骤数 | N 步 |
| 概念数 | M 个 |
| guide.md | XKB（源文件的 Y%） |
| guide.html | XKB（guide.md 的 Y 倍） |
| Stage 5 验证 | ✅ 全部通过 / ⚠️ 部分失败（列出） |

### 概念覆盖
（列出所有概念，标注覆盖情况）

### 交互元素
（列出 HTML 中的交互元素类型和数量）
```

如果 Stage 5 有检查失败，在报告中明确列出哪项失败、失败原因、建议修复方式。

## Output

### 单篇模式

For each question, produce both files in the same directory as the source `explanation.md`:

- **`guide.md`** — 引导式文字讲解（内容脚本）
- **`guide.html`** — 交互式教学体验（效果放大器，基于 guide.md 构建）

Do not modify the original files.

### 系列模式

When Stage 1.5 detects multiple loosely-coupled concept clusters, produce a series:

```
{题目目录}/
├── series.md           # 系列索引：为什么拆、各篇关系、阅读顺序
├── 01-{分册名}/
│   ├── guide.md
│   └── guide.html
├── 02-{分册名}/
│   ├── guide.md
│   └── guide.html
└── ...
```

- **`series.md`** — 系列索引（必须包含：总述、拆分理由、依赖关系图、各分册摘要）
- 每个 **`{NN}-{分册名}/`** — 独立的分册，包含 guide.md + guide.html
- 分册编号按依赖拓扑顺序排列（被依赖的排前面）
- 每个分册独立走 Stage 2-5，保证内部概念链闭环

Do not modify the original files.

## 批量处理

当需要处理多道题目时（如整个题库），按以下策略调度：

**执行顺序**：按优先级 P0 → P1 → P2，同优先级内按题号顺序

**并行策略**：
- 每道题独立执行 Stage 1-5（含 Stage 1.5），互不依赖
- 可同时 spawn 多个子 agent 并行处理（建议 ≤3 个并发，避免资源争抢）
- 每个子 agent 完成后独立汇报，不阻塞其他子 agent

**进度追踪**：
- 维护 `batch-progress.tsv`（格式见 `references/batch-progress.md`）
- 每道题完成后更新进度文件
- 全部完成后生成汇总报告 `batch-report.md`

**容错**：
- 单题失败不影响其他题继续执行
- 失败题记录到 `batch-progress.tsv`，最后统一重试

## 异常与边界条件

| 场景 | 触发条件 | 处理动作 |
|------|----------|---------|
| 源文件不存在 | `explanation.md` 路径 404 或文件为空 | 终止，告知用户"源文件不存在或为空" |
| solution.js 缺失 | 目录下无 `solution.js` | Stage 5 跳过 code concatenability 检查，在输出中标注 `⚠️ 无 solution.js 对照` |
| 概念提取为空 | Stage 1 扫描后 0 个概念 | 重新扫描一次；仍为 0 则终止，告知用户"源文档无可用技术概念" |
| DAG 有环 | Stage 1 验证发现循环依赖 | 检查环上节点的依赖关系，松开最弱的一条边（改为"可选前置"），记录修正原因 |
| 拓扑排序失败 | 处理完数量 ≠ 总节点数 | 回 Stage 1 重新检查 DAG，标注未处理节点 |
| guide.md 过大 | 单篇模式：新文件 > 源 explanation.md × 150%；系列模式：单分册 guide.md > 该分册对应概念数 × 600 字节 × 150% | 精简：合并相似步骤、删除冗余类比、压缩代码注释区，重新验证 |
| HTML 生成失败 | Stage 4 中途报错 | 保留已生成的 guide.md，HTML 输出标注 `⚠️ 生成中断`，告知用户具体失败步骤 |
| 源文档为英文 | 检测到源文档主要语言为英文 | 正常处理，guide.md 和 guide.html 使用中文讲解（面向中文用户），代码和术语保留英文 |
| 步骤代码 >10 行 | Stage 3 验证发现超限 | 如果是中间步骤：拆分为两个子步骤或提取辅助函数到前置步骤。如果是最终拼装步骤：允许 ≤20 行，无需拆分 |
| 系列分册概念不闭环 | 分册内有概念依赖其他分册 | 将缺失概念纳入当前分册，或将该概念所在分册提前；确保每个分册可独立阅读 |
| 系列分册间循环依赖 | 分册 A 依赖 B，B 又依赖 A | 找到最弱的跨分册依赖边，将其改为"前置知识提示"（在分册开头标注"建议先阅读 XX 分册"），松开循环 |
| 分册概念数 > 15 | 单个分册仍然过大 | 进一步拆分：在分册内找入度最高的节点作为分割点，一分为二 |
| series.md 生成失败 | 系列模式下索引文件写入出错 | 保留各分册 guide.md/guide.html，series.md 标注 `⚠️ 索引生成失败`，手动补建索引即可 |

**原则**：异常先告知用户，再按规则处理；绝不静默跳过或静默失败。告知时说明：什么异常、怎么处理的、结果是否可信。
