# HTML 模板使用说明

## 核心理念

**agent 不写 CSS/JS，只填内容。** 所有基础设施（样式、交互、键盘导航）已内置在模板中。

## 替换规则

模板中有 4 个占位符需要替换：

| 占位符 | 说明 | 示例 |
|--------|------|------|
| `__TITLE__` | 页面标题 | `03 防抖 & 节流 — 引导式讲解` |
| `__SUBTITLE__` | 副标题 | `基于 explanation.md 改写 · 逐步引导 · 可运行验证` |
| `__NAV_ITEMS__` | 导航栏锚点 | 见下方 |
| `__STEP_SECTIONS__` | 所有步骤内容 | 见下方 |

## 导航栏格式

每个 step 对应一个 `<a>` 标签：

```html
<a href="#step-1">1. 为什么需要防抖</a>
<a href="#step-2">2. 定时器基础</a>
<a href="#step-3">3. this 传递</a>
<!-- ... -->
```

## Step Section 格式

每个 step 使用以下**固定结构**，不要修改 class 名或 HTML 结构：

```html
<div class="step" id="step-N">
  <div class="step-header" onclick="toggleStep(this)">
    <span class="step-num">N</span>
    <span class="step-title">步骤标题</span>
    <span class="step-arrow">▼</span>
  </div>
  <div class="step-body">

    <!-- 困境（必填） -->
    <div class="dilemma">困境描述文字</div>

    <!-- 思考（必填） -->
    <div class="think">引导思考文字</div>

    <!-- 解法（必填） -->
    <div class="solution">解法说明文字</div>

    <!-- 日常类比（选填） -->
    <div class="analogy">类比文字</div>

    <!-- 注意事项（选填） -->
    <div class="warning">注意文字</div>

    <!-- 代码块（必填，每个 step 至少一个） -->
    <div class="code-wrap">
      <div class="code-header">
        <span class="code-lang">JavaScript</span>
        <div class="code-actions">
          <button class="btn-copy" onclick="copyCode(this)">复制</button>
          <button class="btn-run" onclick="runCode(this)">运行 ▶</button>
        </div>
      </div>
      <pre><code>// 代码内容，用纯文本，不要 HTML 转义
function example() {
  console.log('hello');
}</code></pre>
      <div class="output"></div>
    </div>

    <!-- 面试追问（选填） -->
    <div class="question" onclick="toggleQA(this)">
      <div class="answer">回答内容</div>
    </div>

  </div>
</div>
```

## 代码块规则

- 代码放在 `<pre><code>` 内，**纯文本**，不要 HTML 实体转义
- 每个 step 至少一个 `.code-wrap`
- 一个 step 内可以放多个代码块（对比 before/after 时）
- 运行按钮自动捕获 `console.log` 输出并显示在 `.output` 中

## 内容 class 对照表

| class | 何时用 | 数量 |
|-------|--------|------|
| `.dilemma` | 每个 step 必填，描述"为什么需要这个概念" | 1 per step |
| `.think` | 每个 step 必填，引导思考 | 1 per step |
| `.solution` | 每个 step 必填，给出解法 | 1 per step |
| `.analogy` | 选填，日常类比帮助理解 | 0-2 per step |
| `.warning` | 选填，易错点或注意事项 | 0-2 per step |
| `.question` | 选填，面试追问 Q&A | 0-3 per step |

## 生成流程

1. 从 `html-skeleton.html` 复制完整内容
2. 替换 `__TITLE__`、`__SUBTITLE__`
3. 生成 `__NAV_ITEMS__`（每个 step 一个 `<a>`）
4. 生成 `__STEP_SECTIONS__`（每个 step 一个完整的 div.step）
5. 输出为 `guide.html`

**不要修改 `<style>` 和 `<script>` 部分。**
